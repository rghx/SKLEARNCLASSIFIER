from .classifierpy import classifiertemplate

__version__ = '0.1.0'
